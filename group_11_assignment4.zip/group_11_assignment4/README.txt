1) Open the file and press "run" 
2) To move the paddle on the left, use "w" and "s" 
3) To move the paddle on the right, use the UP- and DOWN-arrow keys. 
4) This game is like Pong. The objective is to hit the ball with a paddle such that it stays in play. 
5) When the ball gets past the paddle, a gameover screen will occur. 
6) To replay the game, follow the on-screen prompt, and press "n".